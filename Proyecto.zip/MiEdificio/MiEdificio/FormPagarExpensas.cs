﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class FormPagarExpensas : Form
    {

        private int numMenu = 0;

        public FormPagarExpensas(int numMenu)
        {
            this.numMenu = numMenu;
            InitializeComponent();
        }

        private void FormPagarExpensas_Load(object sender, EventArgs e)
        {
            if (this.numMenu == 2)
            {
                this.Text = "MiEdificio - Visualizar Documentos";
            }
        }
    }
}
