﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public static class PermisosConstantes
    {

        public const string Valor2 = "Texto";

        public const string ABM_Admin = "ABM-Admin";
        public const string Lectura_Admin = "Lectura-Admin";
        public const string Alta = "Alta";
        public const string Baja = "Baja";
        public const string Modificacion = "Modificacion";
        public const string Lectura = "Lectura";
        public const string ABM_Altas = "ABM-Altas";
        public const string Lectura_Altas = "Lectura-Altas";
        public const string Lectura_Reportes = "Lectura-Reportes";
        public const string Lectura_Ayuda = "Lectura-Ayuda";
        public const string ABM_Gestiones = "ABM-Gestiones";
        public const string Lectura_Gestiones = "Lectura-Gestiones";
        public const string ABM_Usuario = "ABM-Usuario";
        public const string ABM_Reservas = "ABM-Reservas";
        public const string Lectura_Reservas = "Lectura-Reservas";


    }
}
