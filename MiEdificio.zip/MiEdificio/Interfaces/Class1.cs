﻿namespace Interfaces
{
    public class Class1
    {
    }
}